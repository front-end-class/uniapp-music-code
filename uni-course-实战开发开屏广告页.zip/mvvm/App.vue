<script>
	export default {
		onLaunch() {
			console.log('App Launch')
		},
		onShow() {
			console.log('App Show')
			let adShowTime = (10 * 60 * 1000)  // 10分钟（单位毫秒）
			// let adShowTime = (3 * 1000)  // 测试 3秒（单位毫秒）
			let nowTime = (new Date()).getTime()
			let leaveTime = this.$store.state.leaveTime
			
			if ((nowTime - leaveTime) > adShowTime && leaveTime > 10) {
				console.log('出现广告吧')
				uni.navigateTo({
					url: '/pages/account/ad'
				});
			}
		},
		onHide() {
			console.log('App Hide')
			// 记录离开时间
			this.$store.commit('storeLeaveTime')
		}
	}
</script>

<style lang="scss">
@import './common/css/common.scss';
@import './common/css/iconfont.css';
</style>
