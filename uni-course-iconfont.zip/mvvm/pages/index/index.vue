<template>
	<view class="content">
		<view class="iconfont">&#xe64f;</view>
		<view class="iconfont">&#xe604;</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>
.content input{
	padding: 10px;
	margin: 10px;
	border: 1px solid #ddd;
}
</style>
