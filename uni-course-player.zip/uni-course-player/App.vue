<script>
	export default {
		onLaunch() {
		},
	}
</script>

<style lang="scss">
@import './common/css/common.scss';
@import './common/css/iconfont.css';
</style>
