<template>
	<view>
		<view>
			登录状态: {{isLogin}}
		</view>
		<button @click="login(true)">登录</button>
		<button @click="login(false)">退出登录</button>
		
		<navigator url="../index/index">去首页</navigator>
	</view>
</template>

<script>
	import { mapState } from 'vuex';
	export default {
		data() {
			return {
				
			};
		},
		computed: {
		   ...mapState(['isLogin'])
		},
		methods: {
			// 改变登录状态
			login (bool) {
			   this.$store.commit('storeLogin', bool)
			},
		},
	}
</script>
<style lang="scss">

</style>