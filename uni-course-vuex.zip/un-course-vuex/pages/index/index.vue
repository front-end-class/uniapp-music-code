<template>
	<view class="content">
		<view class="text-area">
			<text class="title">当前是首页</text>
			<view>
				登录状态: {{isLogin}}
			</view>
		</view>
	</view>
</template>

<script>
	import { mapState } from 'vuex';
	export default {
		data() {
			return {
				
			};
		},
		computed: {
		   ...mapState(['isLogin'])
		},
		methods: {
			
		},
	}
</script>

<style>
	
</style>
