import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const store = new Vuex.Store({
	state: {
	    isLogin: false
	},
	mutations: {
		// 定义一个操作isLogin状态的方法
	    storeLogin (state, payload) {
	      state.isLogin = payload
	    }
	}
})

export default store
