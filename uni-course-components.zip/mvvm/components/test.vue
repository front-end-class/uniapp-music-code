<template>
	<view class="song">
		<button type="primary" @click="sendMsg">测试</button>
	</view>
</template>

<script>
export default {
    // 从父组件传值的
    props:{
        
    },
    data() {
		return {
			
		}
    },
    methods:{
		sendMsg () {
			// 传递一个事件和信息
			this.$emit('getMsg', '我是子组件的信息')
		}
    }
}
</script>
<style lang="scss" scoped>

</style>
