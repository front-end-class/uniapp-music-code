<template>
	<view class="content">
		<!-- 从test组件传信息 -->
		<test @getMsg="openMsg"/>
		<view>单个渲染</view>
		<song 
			:imgSrc="song.img"
			:title="song.title"
			:price="song.price"
			:marketPrice="song.marketPrice"
		/>
		<view>列表渲染</view>
		<songItem v-for="(item, index) in songList" :item="item" :key="index"/>
	</view>
</template>
<script>
	import song from '../../components/song.vue'
	import songItem from '../../components/songItem.vue'
	import test from '../../components/test.vue'
	export default {
		components: {
			song,
			songItem,
			test
		},
		data() {
			return {
				song: {
					img: 'http://gw.alicdn.com/bao/uploaded/i3/1917047079/O1CN01VlEDD522AEJzpw3A5_!!2-item_pic.png_360x10000.jpg',
					title: 'Apple/苹果 iPhone 11 Pro',
					price: '8699.00',
					marketPrice: '￥8699.00',
				},
				songList: [
					{
						img: 'http://gw.alicdn.com/bao/uploaded/i3/1917047079/O1CN01VlEDD522AEJzpw3A5_!!2-item_pic.png_360x10000.jpg',
						title: 'Apple/苹果 iPhone 11 Pro',
						price: '8699.00',
						marketPrice: '￥8699.00',
					},
					{
						img: 'http://gw.alicdn.com/bao/uploaded/i3/1917047079/O1CN01VlEDD522AEJzpw3A5_!!2-item_pic.png_360x10000.jpg',
						title: 'Apple/苹果 iPhone 11 Pro',
						price: '8699.00',
						marketPrice: '￥8699.00',
					},
					{
						img: 'http://gw.alicdn.com/bao/uploaded/i3/1917047079/O1CN01VlEDD522AEJzpw3A5_!!2-item_pic.png_360x10000.jpg',
						title: 'Apple/苹果 iPhone 11 Pro',
						price: '8699.00',
						marketPrice: '￥8699.00',
					},
				]
			}
		},
		onLoad() {
		},
		methods: {
			openMsg (msg) {
				// 接受test组件的信息
				console.log(msg)
			}
		}
	}
</script>

<style>
page {
	background: #f2f2f2;
}
</style>
