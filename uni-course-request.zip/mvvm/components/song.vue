<template>
	<view class="song">
		<image class="img" :src="imgSrc"></image>
		<view class="desc">{{ title }}</view>
		<view class="flex-box">
			<view class="price">￥{{price}}</view>
			<view class="market-price">{{marketPrice}}</view>
		</view>
	</view>
</template>

<script>
export default {
    // 从父组件传值的
    props:{
        imgSrc: {
            type: String,
            default: ''
        },
		title: {
		    type: String,
		    default: ''
		},
		price: {
            type: String,
            default: ''
        },
		marketPrice: {
		    type: String,
		    default: ''
		},
    },
    data() {
		return {
			
		}
    },
    methods:{

    }
}
</script>
<style lang="scss" scoped>
.song {
	position: relative;
	width: 342rpx;
	height: 502rpx;
	line-height: 34rpx;
	color:#333;
	background:#fff;
	border-radius: 10rpx;
	overflow:hidden;
	font-size: 26rpx;
	.img {
		display: block;
		width: 342rpx;
		height: 342rpx;
		margin-bottom: 24rpx;
		background: #eee;
	}
	.desc {
		height: 64rpx;
		margin-top: 12rpx;
		line-height: 30rpx;
	}
	.price{
		color:#ff5000;
	}
	.market-price{
		padding-left: 10px;
		font-size: 24rpx;
		color: #979797;
		text-decoration: line-through;
	}
}
</style>
