<template>
	<view class="content">
		<view>
			{
				page: 'index', 
				id: 123
			}
		</view>
		<button type="primary" @click="goUrl">传上面的参数到列表</button>
		<view>请求数据：{{title}}</view>
	</view>
</template>

<script>
	import { test200 } from "@/api/test.js"
	export default {
		data() {
			return {
				title: ''
			}
		},
		onLoad() {
			this.getData()
		},
		methods: {
			// 跳转链接
			goUrl () {
				let item = {
					page: 'index', 
					id: 123
				}
				// 去列表并传参到列表 
				uni.navigateTo({
				    url: '/pages/list/list?item=' + encodeURIComponent(JSON.stringify(item))
				});
			},
			// 获取数据
			getData () {
				test200().then(res => {
					this.title = res.data
				})
			}
		}
	}
</script>

<style>
.content input{
	padding: 10px;
	margin: 10px;
	border: 1px solid #ddd;
}
</style>
