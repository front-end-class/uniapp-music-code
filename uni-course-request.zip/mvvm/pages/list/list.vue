<template>
	<view>
		<view>我是列表页</view>
		
		下面是首页过来的页面参数
		<view>
			{{item}}
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				item: {}
			};
		},
		// 页面接受参数
		onLoad: function (option) {
			console.log(option)
		    const item = JSON.parse(decodeURIComponent(option.item));
			
			this.item = item
		}
	}
</script>

<style lang="scss">

</style>
